/** 
 *  this method says how to print a date 
 *  return a String how the object is printed
 */
public String toString(){
    return day + " " + month + " " + year;    // European 
    //return year + ", " + month + " " + day; // American
}

