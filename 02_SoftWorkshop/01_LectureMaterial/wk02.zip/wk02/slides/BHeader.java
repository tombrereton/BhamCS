/** BankAccount is a class for a very simple bank
 *  account created from a bank account and the
 *  name of the account holder.
 *  @author   Manfred Kerber
 *  @version  6 October 2015
 */
public class BankAccount{
    private int     accountNumber;
    private String  accountName;
    private int     balance;

