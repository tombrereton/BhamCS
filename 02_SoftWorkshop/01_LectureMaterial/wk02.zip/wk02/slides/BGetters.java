/* Now we write methods to get the parts of a
 * BankAccount, so called accessor methods.
 */
/** 
 *  @return the account number of a
 *  BankAccount as int
 */
public int getAccountNumber(){
    return accountNumber;
}

/** 
 *  @return the accountName as a String
 */
public String getAccountName(){
    return accountName;
}

/** 
 *  @return the balance of a BankAccount 
 */
public int getBalance(){
    return balance;
}
