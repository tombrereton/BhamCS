/** This constructor creates a date from the three parts: 
 *  day, month, and year, which are an int, a String, 
 *  and an int, respectively.
 */
public Date (int    d, 
             String m, 
             int    y){
    day      = d;
    month    = m;
    year     = y;
}

