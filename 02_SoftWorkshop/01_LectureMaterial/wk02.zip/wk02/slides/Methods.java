/** Now we write *methods* to get the parts of a Date,
 *  so called *accessor methods* or *getters*
 */

/** 
 * return the day of a Date 
 */
public int getDay(){
    return day;
}

/** 
 * return the month of a Date 
 */
public String getMonth(){
    return month;
}
    
/**
 * return the year of a Date 
 */
public int getYear(){
    return year;
}


